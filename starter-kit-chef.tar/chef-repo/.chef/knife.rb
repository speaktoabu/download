current_dir = ::File.dirname(__FILE__)
cookbook_path   [::File.join(current_dir, "../cookbooks")]
ssl_verify_mode :verify_none
